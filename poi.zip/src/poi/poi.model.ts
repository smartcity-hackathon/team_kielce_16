export interface Toilet {
    readonly id: number;
    readonly name: string;
    readonly location: string;
    readonly cabin: number;
    readonly charge: boolean;
    readonly seasonTime: string;
    readonly nonSeasonTime: string;
  }