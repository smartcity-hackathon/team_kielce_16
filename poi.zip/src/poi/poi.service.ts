import { Injectable } from '@nestjs/common';
const _toilets = require('./../data/toilets.json');
const _smog = require('./../data/smog.json');
const _policja = require('./../data/policja.json');
const _urzad = require('./../data/urzad.json');
const _zabytek = require('./../data/zabytek.json');
const proj4 = require('proj4');

@Injectable()
export class PoiService {
    findAll(body: any): any[] {
        if (body.type === 'WC') {
            return _toilets;
        }
        else if (body.type === 'SMOG') {
            return _smog;
        }
        else if (body.type === 'POLICJA') {
            return _policja;
        }
        else if (body.type === 'URZAD') {
            return _urzad;
        }
        else if (body.type === 'ZABYTEK') {
            return _zabytek;
        }
        return [];
    }

    findNearest(body: any): any {
        let objects;
        if (body.type === 'WC') {
            objects = _toilets;
        }

        if (body.type === 'SMOG') {
            objects = _smog;
        }

        if (body.type === 'POLICJA') {
            objects = _policja;
        }

        if (body.type === 'URZAD') {
            objects = _urzad;
        }

        if (body.type === 'ZABYTEK') {
            objects = _zabytek;
        }
        let nearest = null;
        let nearestDistance = null;

        objects.forEach(element => {
            let coords;
            if (body.type === 'SMOG') {
                coords = [element.sensor.lng, element.sensor.lat];
            }
            else { 
                coords = element.json_geometry.coordinates;
            }
            const gpsCoords = proj4('+proj=tmerc +lat_0=0 +lon_0=21 +k=0.999923 +x_0=7500000 +y_0=0 +ellps=GRS80 +units=m +no_defs ', 'EPSG:4326', coords);
            const distance = this.distance(body.lat, body.long, gpsCoords[1], gpsCoords[0], 'K');
            if (!nearestDistance || distance < nearestDistance) {
                nearestDistance = distance;
                nearest = element;
            }
        });
        nearest.id = (body.type + '_FID' + nearest.FID).toUpperCase();
        if (body.type === 'SMOG') {
            nearest.id = (body.type + '_' + nearest.sensor._id).toUpperCase();
        }
        return nearest;
    }

    distance(lat1: number, lon1: number, lat2: number, lon2: number, unit: string) {
        const radlat1 = Math.PI * lat1 / 180;
        const radlat2 = Math.PI * lat2 / 180;
        const theta = lon1 - lon2;
        const radtheta = Math.PI * theta / 180;
        let dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
        dist = Math.acos(dist);
        dist = dist * 180 / Math.PI;
        dist = dist * 60 * 1.1515;
        if (unit === 'K') { dist = dist * 1.609344; }
        if (unit === 'N') { dist = dist * 0.8684; }
        return dist;
    }

}
