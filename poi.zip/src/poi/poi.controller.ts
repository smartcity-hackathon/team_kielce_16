
import { Controller, Get, Body } from '@nestjs/common';
import { Post } from '@nestjs/common';
import { PoiService } from './poi.service';

@Controller('poi')
export class PoiController {
    constructor(private readonly poiService: PoiService) {
    }
    @Post()
    findAll(@Body() body: any) {
        return this.poiService.findAll(body);
    }

    @Post('near')
    findNearest(@Body() body: any) {
        return this.poiService.findNearest(body);
    }
}
