var proj4 = require('proj4');

var coords = [ 7474045.7, 5637065.94 ];

// proj4.defs["EPSG:2180"] = "+proj=tmerc +lat_0=0 +lon_0=19 +k=0.9993 +x_0=500000 +y_0=-5300000 +ellps=GRS80 +units=m +no_defs";
var result = proj4("+proj=tmerc +lat_0=0 +lon_0=21 +k=0.999923 +x_0=7500000 +y_0=0 +ellps=GRS80 +units=m +no_defs ", "EPSG:4326", coords);

console.log(result);