//cosurfing token, set when cosurfing enabled

var currentTab;
var state={};


document.addEventListener('DOMContentLoaded', function() {
	var button=document.getElementById('switchButton');

	getState();
	initializePopup();

	function getState() {
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
			currentTab=tabs[0];

			chrome.tabs.sendMessage(currentTab.id, {
				type: 'getState'
			}, function(response) {
				state=response;
				updateButton();
			});
		});
	}

	function initializePopup() {

		button.addEventListener("click", function(){
			if(state.enabled) {
				state.enabled=!state.enabled;
			}
			
			chrome.tabs.sendMessage(currentTab.id, {
				type: 'setState',
				state: state
			}, function(response) {
			});
			updateButton();
		});

	}

	function updateButton() {
		if(state.enabled) {
			button.innerHTML = "Disable";
		} else {
			button.innerHTML = "Enable";
		}
	}

});
