

var state={
	enabled: Boolean(localStorage.getItem("cosurfingEnabled"))
}

var loaded=false;
if(state.enabled) {
	loadCosurfing();
}

chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		if (request.type=='getState') {
			sendResponse(state);
		} else if(request.type=='setState') {
			state=request.state;	
			localStorage.setItem("cosurfingEnabled", state.enabled);
			if(state.enabled && !loaded) {
				loadCosurfing();
			}
		}
	});

function loadCosurfing() {
	loaded=true;
	var fileref=document.createElement('script'); 
	fileref.setAttribute("type","text/javascript");
	fileref.setAttribute("src","https://mysocialseller.com/pub/messenger.plugin.js");
	document.body.appendChild(fileref);
}
